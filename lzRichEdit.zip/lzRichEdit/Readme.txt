﻿Este pacote serve para trabalhar com textos formatados, suporta o formato Rich Text.

O controle ainda tem alguns erros:

Algumas propriedades não respondem da mesma forma no Windows e no Linux.


Testado no Windows 7 com Lazarus 0.9.31/FPC 2.5.1
Testado no Linux/GTK2 com Lazarus 0.9.30.2RC1-0/FPC 2.4.4


Elson Junio (elsonjunio@yahoo.com.br)
